export type HeldItem = 'none' | 'fire-extinguisher';
export type ExtinguisherPosition = 'stored' | 'held';
export type ExtinguisherReadiness = 'safe' | 'prepared';

export interface EquipmentState {
  readonly heldItem: HeldItem;
  readonly extinguisher: {
    readonly position: ExtinguisherPosition;
    readonly readiness: ExtinguisherReadiness;
  };
}

export interface EquipmentAction {
  readonly accepted: boolean;
  readonly message: string;
  readonly state: EquipmentState;
}

export function createEquipmentState(): EquipmentState {
  return {
    heldItem: 'none',
    extinguisher: {
      position: 'stored',
      readiness: 'safe',
    },
  };
}

export function takeFireExtinguisher(state: EquipmentState): EquipmentAction {
  if (state.heldItem !== 'none') {
    return reject(state, 'Нельзя взять второй предмет: в руке уже огнетушитель.');
  }

  return accept(
    {
      heldItem: 'fire-extinguisher',
      extinguisher: { ...state.extinguisher, position: 'held' },
    },
    'Огнетушитель взят в руку. Откройте его подробный осмотр, чтобы подготовить.',
  );
}

export function prepareFireExtinguisher(state: EquipmentState): EquipmentAction {
  if (state.heldItem !== 'fire-extinguisher') {
    return reject(state, 'Огнетушитель нужно сначала взять в руку.');
  }

  if (state.extinguisher.readiness === 'prepared') {
    return reject(state, 'Огнетушитель уже подготовлен.');
  }

  return accept(
    {
      ...state,
      extinguisher: { ...state.extinguisher, readiness: 'prepared' },
    },
    'Пломба снята: огнетушитель подготовлен к применению.',
  );
}

export function applyFireExtinguisher(state: EquipmentState): EquipmentAction {
  if (state.heldItem !== 'fire-extinguisher') {
    return reject(state, 'Нечего применять: огнетушитель не взят в руку.');
  }

  if (state.extinguisher.readiness !== 'prepared') {
    return reject(state, 'Рукоятка не поддаётся — огнетушитель не подготовлен.');
  }

  return accept(state, 'Огнетушитель подготовлен. Очаг для применения появится на следующем этапе.');
}

function accept(state: EquipmentState, message: string): EquipmentAction {
  return { accepted: true, message, state };
}

function reject(state: EquipmentState, message: string): EquipmentAction {
  return { accepted: false, message, state };
}
